# Импортируем необходимые компоненты из FastAPI
from fastapi import APIRouter, Response, Depends
# Импортируем схемы данных для валидации и сериализации
from .schemas import UserSchema, UserRegisterSchema, UserLoginSchema
# Импортируем модель пользователя
from .models import UserModel
# Импортируем сервисный слой с бизнес-логикой
from . import service
# Импортируем модуль с настройками базы данных
from auth import database

# Создаём роутер для обработки запросов, связанных с пользователями
# prefix="/user" - все маршруты будут начинаться с /user
# tags=["user"] - для группировки в документации API
router2 = APIRouter(
    prefix="/user",
    tags=["user"]
)

# Обработчик GET-запроса для получения списка всех пользователей
# response_model=list[UserSchema] - указывает формат ответа
@router2.get('/all', response_model=list[UserSchema])
async def get_all_users(
    session: database.SessionDep,  # Зависимость для получения сессии БД
    user: UserModel = Depends(service.get_current_user)  # Зависимость для проверки авторизации
):
    # Выводим имя текущего пользователя в консоль
    print(user.name)
    # Возвращаем список всех пользователей через сервисный слой
    return await service.get_all_users(session)

# Обработчик POST-запроса для регистрации нового пользователя
@router2.post('/register')
async def register(
    data: UserRegisterSchema,  # Данные для регистрации (email, пароль и т.д.)
    session: database.SessionDep  # Зависимость для получения сессии БД
):
    # Передаём данные в сервисный слой для регистрации
    return await service.register(data, session)

# Обработчик POST-запроса для авторизации пользователя
@router2.post('/login')
async def login(
    response: Response,  # Объект ответа для установки cookies
    data: UserLoginSchema,  # Данные для входа (email и пароль)
    session: database.SessionDep  # Зависимость для получения сессии БД
):
    # Передаём данные в сервисный слой для авторизации
    return await service.login(response, data, session)