import { setUserData } from './set-user-data.js'

document.addEventListener('DOMContentLoaded', () => {
  setUserData()
})
